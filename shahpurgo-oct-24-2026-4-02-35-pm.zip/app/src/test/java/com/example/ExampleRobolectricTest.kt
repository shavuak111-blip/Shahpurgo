package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.GroceryCategory
import com.example.model.SampleData
import com.example.viewmodel.GroceryViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read ShahpurGo brand string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ShahpurGo", appName)
    val tagline = context.getString(R.string.tagline)
    assertEquals("Shahpur Ka Apna Delivery App", tagline)
  }

  @Test
  fun `verify initial Shahpur catalogue contains Himachal and Kangra items`() {
    val items = SampleData.initialCatalogue
    assertTrue(items.any { it.name.contains("Kangra", ignoreCase = true) })
    assertTrue(items.any { it.name.contains("Himachal", ignoreCase = true) || it.name.contains("Kinnaur", ignoreCase = true) })
    assertTrue(items.any { it.category == GroceryCategory.KANGRA_SPECIALS })
  }

  @Test
  fun `cart and order placement flow in ViewModel`() {
    val viewModel = GroceryViewModel()
    val firstItem = viewModel.uiState.value.catalogue.first()

    // Add 2 items to cart
    viewModel.addToCart(firstItem)
    viewModel.addToCart(firstItem)

    assertEquals(1, viewModel.uiState.value.cart.size)
    assertEquals(2, viewModel.uiState.value.cartItemCount)
    assertEquals(firstItem.price * 2, viewModel.uiState.value.cartSubtotal, 0.01)

    // Set tip
    viewModel.setDeliveryTip(20.0)
    assertEquals(20.0, viewModel.uiState.value.selectedTip, 0.01)

    // Place order
    val placedOrder = viewModel.placeOrder()
    assertNotNull(placedOrder)
    assertEquals(0, viewModel.uiState.value.cart.size)
    assertTrue(placedOrder!!.paymentMethod.contains("Cash on Delivery"))
  }

  @Test
  fun `scratch card rewards credit coins`() {
    val viewModel = GroceryViewModel()
    val initialCoins = viewModel.uiState.value.user.coinsBalance

    viewModel.scratchCard()

    assertTrue(viewModel.uiState.value.scratchCardRevealed)
    assertEquals(
      initialCoins + viewModel.uiState.value.scratchedRewardAmount,
      viewModel.uiState.value.user.coinsBalance
    )
  }

  @Test
  fun `verify order tracking progress sequence from Order Placed to Delivered`() {
    val viewModel = GroceryViewModel()
    val order = viewModel.uiState.value.orders.first()

    // Test transition to Order Placed
    viewModel.updateOrderStatus(order.id, com.example.model.OrderStatus.CONFIRMED)
    assertEquals("Order Placed", viewModel.uiState.value.orders.first { it.id == order.id }.status.title)

    // Test transition to Order Packed
    viewModel.updateOrderStatus(order.id, com.example.model.OrderStatus.PACKED)
    assertEquals("Order Packed", viewModel.uiState.value.orders.first { it.id == order.id }.status.title)

    // Test transition to Out for Delivery
    viewModel.updateOrderStatus(order.id, com.example.model.OrderStatus.OUT_FOR_DELIVERY)
    assertEquals("Out for Delivery", viewModel.uiState.value.orders.first { it.id == order.id }.status.title)

    // Test transition to Delivered
    viewModel.updateOrderStatus(order.id, com.example.model.OrderStatus.DELIVERED)
    assertEquals("Delivered", viewModel.uiState.value.orders.first { it.id == order.id }.status.title)
  }

  @Test
  fun `verify past orders history and reorder functionality`() {
    val viewModel = GroceryViewModel()
    val pastOrders = viewModel.uiState.value.orders
    assertTrue(pastOrders.size >= 2)

    val targetOrder = pastOrders.first()
    val totalItemsInOrder = targetOrder.items.sumOf { it.quantity }

    // Execute re-order
    viewModel.reorder(targetOrder)

    // Verify cart now contains the items from the target order
    assertTrue(viewModel.uiState.value.cart.isNotEmpty())
    assertEquals(totalItemsInOrder, viewModel.uiState.value.cartItemCount)
    assertTrue(viewModel.uiState.value.userFeedbackMessage?.contains(targetOrder.id) == true)
  }

  @Test
  fun `verify estimated delivery time calculation varies by order size and time of day`() {
    val cal = java.util.Calendar.getInstance()

    // 1. Afternoon off-peak time (2:00 PM / 14:00)
    cal.set(java.util.Calendar.HOUR_OF_DAY, 14)
    cal.set(java.util.Calendar.MINUTE, 0)
    val afternoonMillis = cal.timeInMillis

    // Small order (1 item): Base 12 + Pack 1 + Traffic 1 = 14 mins (14-18 mins)
    val smallOrderOffPeak = com.example.model.calculateEstimatedDeliveryTime(itemCount = 1, currentTimeMillis = afternoonMillis)
    assertEquals(14, smallOrderOffPeak.minMinutes)
    assertEquals(18, smallOrderOffPeak.maxMinutes)
    assertEquals("14–18 mins", smallOrderOffPeak.rangeString)
    assertTrue(smallOrderOffPeak.orderSizeContext.contains("Quick Pack"))
    assertTrue(smallOrderOffPeak.trafficContext.contains("Clear Valley"))

    // Large order (15 items): Base 12 + Pack 9 + Traffic 1 = 22 mins (22-26 mins)
    val largeOrderOffPeak = com.example.model.calculateEstimatedDeliveryTime(itemCount = 15, currentTimeMillis = afternoonMillis)
    assertEquals(22, largeOrderOffPeak.minMinutes)
    assertEquals(26, largeOrderOffPeak.maxMinutes)
    assertEquals("22–26 mins", largeOrderOffPeak.rangeString)
    assertTrue(largeOrderOffPeak.orderSizeContext.contains("Bulky Order"))

    // 2. Evening rush hour on NH-154 (6:30 PM / 18:30)
    cal.set(java.util.Calendar.HOUR_OF_DAY, 18)
    cal.set(java.util.Calendar.MINUTE, 30)
    val eveningRushMillis = cal.timeInMillis

    // Small order (2 items) during evening rush: Base 12 + Pack 1 + Traffic 6 = 19 mins (19-23 mins)
    val rushOrder = com.example.model.calculateEstimatedDeliveryTime(itemCount = 2, currentTimeMillis = eveningRushMillis)
    assertEquals(19, rushOrder.minMinutes)
    assertEquals(23, rushOrder.maxMinutes)
    assertTrue(rushOrder.isRushHour)
    assertTrue(rushOrder.trafficContext.contains("Evening Peak Rush"))

    // 3. ViewModel dynamic ETA updates as items are added to cart
    val viewModel = GroceryViewModel()
    val initialEta = viewModel.uiState.value.estimatedDeliveryInfo
    val firstItem = viewModel.uiState.value.catalogue.first()

    viewModel.addToCart(firstItem)
    val updatedEta = viewModel.uiState.value.estimatedDeliveryInfo
    assertTrue(updatedEta.rangeString.isNotEmpty())
    assertTrue(updatedEta.timeWindowString.startsWith("Arriving by"))
  }
}

