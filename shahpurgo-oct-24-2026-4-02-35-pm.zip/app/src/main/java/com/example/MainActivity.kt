package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ShahpurGoBrandHeader
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.CartCheckoutScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LocationPickerScreen
import com.example.ui.screens.MerchantLoginScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.OrderConfirmationAndTrackingScreen
import com.example.ui.screens.OrderHistoryScreen
import com.example.ui.screens.ProfileAndAccountScreen
import com.example.ui.screens.ReferralAndRewardsScreen
import com.example.ui.theme.BrandGreenDark
import com.example.ui.theme.BrandGreenPrimary
import com.example.ui.theme.BrandGreenSurface
import com.example.ui.theme.MountainCardSurface
import com.example.ui.theme.MountainWhite
import com.example.ui.theme.RewardGold
import com.example.ui.theme.ShahpurGoTheme
import com.example.ui.theme.TextMuted
import com.example.viewmodel.GroceryViewModel

enum class MainNavigationTab {
  SHOP,
  TRACK,
  REWARDS,
  PROFILE
}

enum class ActiveSubScreen {
  NONE,
  CART,
  LOCATION_PICKER,
  NOTIFICATIONS,
  ADMIN,
  MERCHANT_LOGIN,
  ORDER_HISTORY
}

class MainActivity : ComponentActivity() {
  private val viewModel: GroceryViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      ShahpurGoTheme {
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val snackbarHostState = remember { SnackbarHostState() }

        var currentTab by remember { mutableStateOf(MainNavigationTab.SHOP) }
        var activeSubScreen by remember { mutableStateOf(ActiveSubScreen.NONE) }

        // Trigger snackbar on feedback
        LaunchedEffect(uiState.userFeedbackMessage) {
          uiState.userFeedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedbackMessage()
          }
        }

        // Handle system back button gracefully
        if (activeSubScreen != ActiveSubScreen.NONE) {
          BackHandler {
            if (activeSubScreen == ActiveSubScreen.ADMIN) {
              viewModel.logoutAdmin()
            }
            activeSubScreen = ActiveSubScreen.NONE
          }
        } else if (currentTab != MainNavigationTab.SHOP) {
          BackHandler {
            currentTab = MainNavigationTab.SHOP
          }
        }

        // When admin view is activated directly from authenticated state
        LaunchedEffect(uiState.isAdminView, uiState.isAdminAuthenticated) {
          if (uiState.isAdminView && uiState.isAdminAuthenticated) {
            activeSubScreen = ActiveSubScreen.ADMIN
          }
        }

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
          topBar = {
            if (activeSubScreen == ActiveSubScreen.NONE) {
              ShahpurGoBrandHeader(
                currentLocation = uiState.currentDeliveryLocation,
                unreadNotificationsCount = uiState.notifications.count { !it.isRead },
                onLocationClick = { activeSubScreen = ActiveSubScreen.LOCATION_PICKER },
                onNotificationClick = { activeSubScreen = ActiveSubScreen.NOTIFICATIONS },
                onOpenMerchantHub = {
                  if (uiState.isAdminAuthenticated) {
                    activeSubScreen = ActiveSubScreen.ADMIN
                  } else {
                    activeSubScreen = ActiveSubScreen.MERCHANT_LOGIN
                  }
                }
              )
            }
          },
          bottomBar = {
            if (activeSubScreen == ActiveSubScreen.NONE) {
              NavigationBar(
                containerColor = MountainCardSurface,
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("main_bottom_nav_bar")
              ) {
                NavigationBarItem(
                  selected = currentTab == MainNavigationTab.SHOP,
                  onClick = { currentTab = MainNavigationTab.SHOP },
                  icon = { Icon(Icons.Default.Storefront, contentDescription = "Shop") },
                  label = { Text("Shop") },
                  modifier = Modifier.testTag("nav_tab_shop"),
                  colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BrandGreenPrimary,
                    selectedTextColor = BrandGreenPrimary,
                    indicatorColor = BrandGreenSurface,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                  )
                )

                NavigationBarItem(
                  selected = currentTab == MainNavigationTab.TRACK,
                  onClick = { currentTab = MainNavigationTab.TRACK },
                  icon = { Icon(Icons.Default.DeliveryDining, contentDescription = "Track") },
                  label = { Text("Track") },
                  modifier = Modifier.testTag("nav_tab_track"),
                  colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BrandGreenPrimary,
                    selectedTextColor = BrandGreenPrimary,
                    indicatorColor = BrandGreenSurface,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                  )
                )

                NavigationBarItem(
                  selected = currentTab == MainNavigationTab.REWARDS,
                  onClick = { currentTab = MainNavigationTab.REWARDS },
                  icon = { Icon(Icons.Default.CardGiftcard, contentDescription = "Rewards") },
                  label = { Text("Rewards") },
                  modifier = Modifier.testTag("nav_tab_rewards"),
                  colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BrandGreenPrimary,
                    selectedTextColor = BrandGreenPrimary,
                    indicatorColor = BrandGreenSurface,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                  )
                )

                NavigationBarItem(
                  selected = currentTab == MainNavigationTab.PROFILE,
                  onClick = { currentTab = MainNavigationTab.PROFILE },
                  icon = { Icon(Icons.Default.Person, contentDescription = "Account") },
                  label = { Text("Account") },
                  modifier = Modifier.testTag("nav_tab_profile"),
                  colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BrandGreenPrimary,
                    selectedTextColor = BrandGreenPrimary,
                    indicatorColor = BrandGreenSurface,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                  )
                )
              }
            }
          }
        ) { innerPadding ->
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
          ) {
            when (activeSubScreen) {
              ActiveSubScreen.CART -> {
                CartCheckoutScreen(
                  uiState = uiState,
                  onBack = { activeSubScreen = ActiveSubScreen.NONE },
                  onAddToCart = { viewModel.addToCart(it) },
                  onDecrementCart = { viewModel.decrementCart(it) },
                  onSelectTip = { viewModel.setDeliveryTip(it) },
                  onSelectPaymentMethod = { viewModel.setPaymentMethod(it) },
                  onPlaceOrder = {
                    val placed = viewModel.placeOrder()
                    if (placed != null) {
                      currentTab = MainNavigationTab.TRACK
                      activeSubScreen = ActiveSubScreen.NONE
                    }
                  },
                  onChangeAddressClick = { activeSubScreen = ActiveSubScreen.LOCATION_PICKER }
                )
              }

              ActiveSubScreen.LOCATION_PICKER -> {
                LocationPickerScreen(
                  currentLocation = uiState.currentDeliveryLocation,
                  savedLocations = uiState.deliveryLocations,
                  onLocationSelected = {
                    viewModel.selectDeliveryLocation(it)
                    activeSubScreen = ActiveSubScreen.NONE
                  },
                  onSaveCustomLocation = { area, addr, landmark, lat, lng ->
                    viewModel.addOrUpdateCustomLocation(area, addr, landmark, lat, lng)
                  },
                  onBack = { activeSubScreen = ActiveSubScreen.NONE }
                )
              }

              ActiveSubScreen.NOTIFICATIONS -> {
                NotificationsScreen(
                  notifications = uiState.notifications,
                  onMarkAllRead = { viewModel.markAllNotificationsRead() },
                  onBack = { activeSubScreen = ActiveSubScreen.NONE }
                )
              }

              ActiveSubScreen.MERCHANT_LOGIN -> {
                MerchantLoginScreen(
                  storeHubId = uiState.storeHubId,
                  onAuthenticate = { pin ->
                    val ok = viewModel.authenticateAdmin(pin)
                    if (ok) {
                      activeSubScreen = ActiveSubScreen.ADMIN
                    }
                    ok
                  },
                  onBackToCustomerStore = { activeSubScreen = ActiveSubScreen.NONE }
                )
              }

              ActiveSubScreen.ADMIN -> {
                AdminDashboardScreen(
                  uiState = uiState,
                  onBackToCustomer = {
                    viewModel.logoutAdmin()
                    activeSubScreen = ActiveSubScreen.NONE
                  },
                  onUpdateStock = { id, delta -> viewModel.updateInventoryStock(id, delta) },
                  onToggleStockAvailability = { id -> viewModel.toggleItemStockAvailability(id) },
                  onAddNewItem = { name, hindi, cat, price, cost, unit, stock ->
                    viewModel.addNewInventoryItem(name, hindi, cat, price, cost, unit, stock)
                  },
                  onUpdateOrderStatus = { id, status -> viewModel.updateOrderStatus(id, status) },
                  onRestockAllLow = { viewModel.restockLowInventory() },
                  onSimulateNewOrder = { viewModel.simulateStoreTestOrder() },
                  onToggleStoreAcceptingOrders = { viewModel.toggleStoreAcceptingOrders() },
                  onUpdateDeliveryRadius = { viewModel.updateDeliveryRadius(it) },
                  onUpdateAdminPasscode = { oldPin, newPin -> viewModel.updateAdminPasscode(oldPin, newPin) },
                  onUpdateStoreManagerName = { viewModel.updateStoreManagerName(it) }
                )
              }

              ActiveSubScreen.ORDER_HISTORY -> {
                OrderHistoryScreen(
                  orders = uiState.orders,
                  onReorder = { ord ->
                    viewModel.reorder(ord)
                    activeSubScreen = ActiveSubScreen.CART
                  },
                  onTrackOrder = { ord ->
                    viewModel.setActiveTrackingOrder(ord)
                    currentTab = MainNavigationTab.TRACK
                    activeSubScreen = ActiveSubScreen.NONE
                  },
                  onBack = { activeSubScreen = ActiveSubScreen.NONE },
                  onBrowseGroceries = {
                    currentTab = MainNavigationTab.SHOP
                    activeSubScreen = ActiveSubScreen.NONE
                  }
                )
              }

              ActiveSubScreen.NONE -> {
                AnimatedContent(
                  targetState = currentTab,
                  transitionSpec = { fadeIn() togetherWith fadeOut() },
                  label = "tab_navigation"
                ) { targetTab ->
                  when (targetTab) {
                    MainNavigationTab.SHOP -> {
                      HomeScreen(
                        uiState = uiState,
                        onCategorySelect = { viewModel.selectCategory(it) },
                        onSearchChange = { viewModel.updateSearchQuery(it) },
                        onAddToCart = { viewModel.addToCart(it) },
                        onDecrementCart = { viewModel.decrementCart(it) },
                        onViewCartClick = { activeSubScreen = ActiveSubScreen.CART },
                        onOpenLocationPicker = { activeSubScreen = ActiveSubScreen.LOCATION_PICKER }
                      )
                    }

                    MainNavigationTab.TRACK -> {
                      OrderConfirmationAndTrackingScreen(
                        order = uiState.activeTrackingOrder ?: uiState.orders.firstOrNull(),
                        onBack = { currentTab = MainNavigationTab.SHOP },
                        onContinueShopping = { currentTab = MainNavigationTab.SHOP },
                        onUpdateStatus = { id, st -> viewModel.updateOrderStatus(id, st) }
                      )
                    }

                    MainNavigationTab.REWARDS -> {
                      ReferralAndRewardsScreen(
                        uiState = uiState,
                        onScratchCard = { viewModel.scratchCard() }
                      )
                    }

                    MainNavigationTab.PROFILE -> {
                      ProfileAndAccountScreen(
                        uiState = uiState,
                        onOpenMerchantPortal = {
                          if (uiState.isAdminAuthenticated) {
                            activeSubScreen = ActiveSubScreen.ADMIN
                          } else {
                            activeSubScreen = ActiveSubScreen.MERCHANT_LOGIN
                          }
                        },
                        onOpenLocationPicker = { activeSubScreen = ActiveSubScreen.LOCATION_PICKER },
                        onOpenOrderHistory = { activeSubScreen = ActiveSubScreen.ORDER_HISTORY },
                        onSelectOrderToTrack = { ord ->
                          viewModel.setActiveTrackingOrder(ord)
                          currentTab = MainNavigationTab.TRACK
                        },
                        onReorder = { ord ->
                          viewModel.reorder(ord)
                          activeSubScreen = ActiveSubScreen.CART
                        }
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
