package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.ui.components.MountainSilhouettes
import com.example.ui.components.ShahpurGoBrandLogo
import com.example.ui.theme.BrandGreenAccent
import com.example.ui.theme.BrandGreenContainer
import com.example.ui.theme.BrandGreenDark
import com.example.ui.theme.BrandGreenLight
import com.example.ui.theme.BrandGreenPrimary
import com.example.ui.theme.BrandGreenSurface
import com.example.ui.theme.MountainBorder
import com.example.ui.theme.MountainCardSurface
import com.example.ui.theme.MountainSnowBackground
import com.example.ui.theme.MountainWhite
import com.example.ui.theme.RewardGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondarySlate
import com.example.viewmodel.GroceryUiState

@Composable
fun ProfileAndAccountScreen(
  uiState: GroceryUiState,
  onOpenMerchantPortal: () -> Unit,
  onOpenLocationPicker: () -> Unit,
  onOpenOrderHistory: () -> Unit,
  onSelectOrderToTrack: (Order) -> Unit,
  onReorder: (Order) -> Unit,
  modifier: Modifier = Modifier
) {
  var showLoginDialog by remember { mutableStateOf(false) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MountainSnowBackground)
      .verticalScroll(rememberScrollState())
      .padding(14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. User Account Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MountainCardSurface),
      border = androidx.compose.foundation.BorderStroke(1.dp, MountainBorder),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("user_profile_card")
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(54.dp)
                .background(BrandGreenContainer, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = BrandGreenDark,
                modifier = Modifier.size(30.dp)
              )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
              Text(
                text = uiState.user.name,
                style = MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimaryDark
                )
              )
              Text(
                text = uiState.user.phone,
                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
              )
              Text(
                text = "Shahpur, Kangra HP",
                style = MaterialTheme.typography.labelSmall.copy(color = BrandGreenLight)
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = BrandGreenSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, BrandGreenPrimary),
            modifier = Modifier
              .clickable { showLoginDialog = true }
              .testTag("account_login_switch_btn")
          ) {
            Text(
              text = "Account",
              style = MaterialTheme.typography.labelMedium.copy(
                color = BrandGreenPrimary,
                fontWeight = FontWeight.Bold
              ),
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Mini Stats row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = BrandGreenSurface,
            modifier = Modifier.weight(1f)
          ) {
            Column(
              modifier = Modifier.padding(10.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text("Wallet Coins", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
              Text(
                "${uiState.user.coinsBalance}",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = BrandGreenDark
                )
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = BrandGreenSurface,
            modifier = Modifier.weight(1f)
          ) {
            Column(
              modifier = Modifier.padding(10.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text("Total Saved", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
              Text(
                "₹${uiState.user.totalSavings.toInt()}",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = BrandGreenPrimary
                )
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = BrandGreenSurface,
            modifier = Modifier.weight(1f)
          ) {
            Column(
              modifier = Modifier.padding(10.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text("Total Orders", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
              Text(
                "${uiState.orders.size}",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimaryDark
                )
              )
            }
          }
        }
      }
    }

    // 2. ShahpurGo Store Partner & Merchant Desk
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = BrandGreenDark),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("admin_mode_entry_card")
        .clickable { onOpenMerchantPortal() }
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(44.dp)
              .background(RewardGold, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.AdminPanelSettings,
              contentDescription = null,
              tint = BrandGreenDark,
              modifier = Modifier.size(26.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "ShahpurGo Merchant Hub",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = MountainWhite
                )
              )
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = if (uiState.isAdminAuthenticated) BrandGreenLight else RewardGold
              ) {
                Text(
                  text = if (uiState.isAdminAuthenticated) "HUB ACTIVE" else "PARTNER DESK",
                  style = MaterialTheme.typography.labelSmall.copy(
                    color = BrandGreenDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp
                  ),
                  modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                )
              }
            }
            Text(
              text = if (uiState.isAdminAuthenticated)
                "Store Terminal Active • Manage orders & inventory"
              else
                "Store Operations, Live Dispatch Desk & Stock Management",
              style = MaterialTheme.typography.labelSmall.copy(
                color = MountainWhite.copy(alpha = 0.85f)
              )
            )
          }
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = RewardGold
        ) {
          Text(
            text = if (uiState.isAdminAuthenticated) "Open Hub" else "Partner Login",
            style = MaterialTheme.typography.labelMedium.copy(
              color = BrandGreenDark,
              fontWeight = FontWeight.ExtraBold
            ),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
          )
        }
      }
    }

    // 3. Saved Addresses Section
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MountainCardSurface),
      border = androidx.compose.foundation.BorderStroke(1.dp, MountainBorder),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Saved Delivery Locations",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimaryDark
            )
          )
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = BrandGreenSurface,
            modifier = Modifier.clickable { onOpenLocationPicker() }
          ) {
            Text(
              text = "+ Add New",
              style = MaterialTheme.typography.labelSmall.copy(
                color = BrandGreenPrimary,
                fontWeight = FontWeight.Bold
              ),
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        uiState.deliveryLocations.forEachIndexed { idx, loc ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.LocationOn,
              contentDescription = null,
              tint = BrandGreenPrimary,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "${loc.tag} - ${loc.areaName}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
              Text(
                text = loc.fullAddress,
                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted),
                maxLines = 1
              )
            }
          }
          if (idx < uiState.deliveryLocations.size - 1) {
            HorizontalDivider(color = MountainBorder.copy(alpha = 0.5f))
          }
        }
      }
    }

    // 4. Recent Order History & Reorder
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MountainCardSurface),
      border = androidx.compose.foundation.BorderStroke(1.dp, MountainBorder),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.History, contentDescription = null, tint = BrandGreenPrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Recent ShahpurGo Orders",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimaryDark
              )
            )
          }

          Surface(
            shape = RoundedCornerShape(6.dp),
            color = BrandGreenSurface,
            modifier = Modifier
              .clickable { onOpenOrderHistory() }
              .testTag("view_all_order_history_btn")
          ) {
            Text(
              text = "View All (${uiState.orders.size}) >",
              style = MaterialTheme.typography.labelSmall.copy(
                color = BrandGreenPrimary,
                fontWeight = FontWeight.Bold
              ),
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        uiState.orders.take(3).forEach { ord ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MountainSnowBackground,
            border = androidx.compose.foundation.BorderStroke(1.dp, MountainBorder),
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(
                modifier = Modifier
                  .weight(1f)
                  .clickable { onSelectOrderToTrack(ord) }
              ) {
                Text(
                  text = "Order #${ord.id}",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                  text = "${ord.items.size} items • ₹${ord.total.toInt()} • ${ord.status.title}",
                  style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                )
              }

              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MountainWhite,
                  border = androidx.compose.foundation.BorderStroke(1.dp, BrandGreenPrimary),
                  modifier = Modifier.clickable { onReorder(ord) }
                ) {
                  Text(
                    text = "Re-order",
                    style = MaterialTheme.typography.labelSmall.copy(
                      color = BrandGreenPrimary,
                      fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                  )
                }

                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = BrandGreenPrimary,
                  modifier = Modifier.clickable { onSelectOrderToTrack(ord) }
                ) {
                  Text(
                    text = "Track",
                    style = MaterialTheme.typography.labelSmall.copy(
                      color = MountainWhite,
                      fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }
            }
          }
        }
      }
    }

    // 5. ShahpurGo Care Helpline & Brand Information
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MountainCardSurface),
      border = androidx.compose.foundation.BorderStroke(1.dp, MountainBorder),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.HeadsetMic, contentDescription = null, tint = BrandGreenPrimary, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Shahpur Local Help & Support",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = TextPrimaryDark
            )
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "Local Shahpur Care Helpline: +91 1892-234567\nSupport hours: 6:00 AM - 11:00 PM daily",
          style = MaterialTheme.typography.bodySmall.copy(color = TextSecondarySlate)
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MountainBorder)

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Landscape, contentDescription = null, tint = BrandGreenPrimary, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "About ShahpurGo",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Brand: ShahpurGo\nTagline: Shahpur Ka Apna Delivery App\nLaunch Location: Shahpur, Kangra, Himachal Pradesh, India\nVersion: 1.0.0 (Made with pride in Kangra Valley)",
          style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, lineHeight = 18.sp)
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))
  }



  // Dialog: Login / Signup Simulation
  if (showLoginDialog) {
    LoginSignupDialog(
      onDismiss = { showLoginDialog = false }
    )
  }
}

@Composable
fun LoginSignupDialog(onDismiss: () -> Unit) {
  var phone by remember { mutableStateOf("98160 12345") }
  var otp by remember { mutableStateOf("4821") }
  var isOtpStep by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = BrandGreenPrimary,
          modifier = Modifier.size(28.dp)
        ) {
          ShahpurGoBrandLogo(modifier = Modifier.padding(3.dp))
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          Text("ShahpurGo", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold))
          Text("Shahpur Ka Apna Delivery App", style = MaterialTheme.typography.labelSmall.copy(color = BrandGreenPrimary))
        }
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!isOtpStep) {
          Text(
            text = "Enter your mobile number to sign in or create an account for Shahpur & Kangra delivery.",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondarySlate)
          )
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Mobile Number (+91)") },
            singleLine = true
          )
        } else {
          Text(
            text = "Enter the 4-digit verification code sent to +91 $phone",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondarySlate)
          )
          OutlinedTextField(
            value = otp,
            onValueChange = { otp = it },
            label = { Text("4-digit OTP") },
            singleLine = true
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (!isOtpStep) {
            isOtpStep = true
          } else {
            onDismiss()
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = BrandGreenPrimary)
      ) {
        Text(if (!isOtpStep) "Send OTP" else "Verify & Login")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}
