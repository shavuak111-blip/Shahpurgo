package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AppNotification
import com.example.model.CartItem
import com.example.model.DeliveryLocation
import com.example.model.EstimatedDeliveryInfo
import com.example.model.GroceryCategory
import com.example.model.GroceryItem
import com.example.model.NotificationType
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.SalesReport
import com.example.model.SampleData
import com.example.model.UserAccount
import com.example.model.calculateEstimatedDeliveryTime
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GroceryUiState(
  val catalogue: List<GroceryItem> = SampleData.initialCatalogue,
  val selectedCategory: GroceryCategory = GroceryCategory.ALL,
  val searchQuery: String = "",
  val cart: List<CartItem> = emptyList(),
  val selectedTip: Double = 20.0,
  val selectedPaymentMethod: String = "Cash on Delivery (COD)",
  val deliveryLocations: List<DeliveryLocation> = SampleData.defaultLocations,
  val currentDeliveryLocation: DeliveryLocation = SampleData.defaultLocations[0],
  val orders: List<Order> = SampleData.initialPastOrders,
  val activeTrackingOrder: Order? = SampleData.initialPastOrders.firstOrNull(),
  val notifications: List<AppNotification> = SampleData.initialNotifications,
  val user: UserAccount = UserAccount(),
  val isAdminView: Boolean = false,
  val isAdminAuthenticated: Boolean = false,
  val adminPasscode: String = "7788",
  val isStoreAcceptingOrders: Boolean = true,
  val storeDeliveryRadiusKm: Int = 8,
  val activeRidersCount: Int = 4,
  val storeManagerName: String = "Amit Sharma (Shahpur Hub)",
  val storeHubId: String = "SHAHPUR-HUB-01",
  val salesReport: SalesReport = SampleData.initialSalesReport,
  val scratchCardRevealed: Boolean = false,
  val scratchedRewardAmount: Int = 35,
  val userFeedbackMessage: String? = null
) {
  val cartSubtotal: Double
    get() = cart.sumOf { it.item.price * it.quantity }

  val cartItemCount: Int
    get() = cart.sumOf { it.quantity }

  val estimatedDeliveryInfo: EstimatedDeliveryInfo
    get() = calculateEstimatedDeliveryTime(cartItemCount)

  val deliveryFee: Double
    get() = if (cartSubtotal >= 199.0 || cart.isEmpty()) 0.0 else 25.0

  val platformFee: Double
    get() = if (cart.isEmpty()) 0.0 else 2.0

  val grandTotal: Double
    get() = if (cart.isEmpty()) 0.0 else (cartSubtotal + deliveryFee + selectedTip + platformFee)

  val filteredCatalogue: List<GroceryItem>
    get() {
      return catalogue.filter { item ->
        val matchesCategory = selectedCategory == GroceryCategory.ALL || item.category == selectedCategory
        val matchesSearch = searchQuery.isBlank() ||
            item.name.contains(searchQuery, ignoreCase = true) ||
            item.hindiName.contains(searchQuery, ignoreCase = true) ||
            item.category.displayName.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
      }
    }
}

class GroceryViewModel : ViewModel() {
  private val _uiState = MutableStateFlow(GroceryUiState())
  val uiState: StateFlow<GroceryUiState> = _uiState.asStateFlow()

  fun selectCategory(category: GroceryCategory) {
    _uiState.update { it.copy(selectedCategory = category) }
  }

  fun updateSearchQuery(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun addToCart(item: GroceryItem) {
    _uiState.update { state ->
      val currentCart = state.cart.toMutableList()
      val existingIndex = currentCart.indexOfFirst { it.item.id == item.id }
      if (existingIndex >= 0) {
        val current = currentCart[existingIndex]
        currentCart[existingIndex] = current.copy(quantity = current.quantity + 1)
      } else {
        currentCart.add(CartItem(item, 1))
      }
      state.copy(cart = currentCart, userFeedbackMessage = "Added ${item.name} to cart")
    }
  }

  fun decrementCart(item: GroceryItem) {
    _uiState.update { state ->
      val currentCart = state.cart.toMutableList()
      val existingIndex = currentCart.indexOfFirst { it.item.id == item.id }
      if (existingIndex >= 0) {
        val current = currentCart[existingIndex]
        if (current.quantity > 1) {
          currentCart[existingIndex] = current.copy(quantity = current.quantity - 1)
        } else {
          currentCart.removeAt(existingIndex)
        }
      }
      state.copy(cart = currentCart)
    }
  }

  fun reorder(order: Order) {
    _uiState.update { state ->
      val currentCart = state.cart.toMutableList()
      order.items.forEach { orderedItem ->
        val index = currentCart.indexOfFirst { it.item.id == orderedItem.item.id }
        if (index >= 0) {
          val existing = currentCart[index]
          currentCart[index] = existing.copy(quantity = existing.quantity + orderedItem.quantity)
        } else {
          currentCart.add(orderedItem)
        }
      }
      state.copy(
        cart = currentCart,
        userFeedbackMessage = "Added ${order.items.size} items from #${order.id} to cart!"
      )
    }
  }

  fun setDeliveryTip(amount: Double) {
    _uiState.update { it.copy(selectedTip = amount) }
  }

  fun setPaymentMethod(method: String) {
    _uiState.update { it.copy(selectedPaymentMethod = method) }
  }

  fun selectDeliveryLocation(location: DeliveryLocation) {
    _uiState.update { it.copy(currentDeliveryLocation = location) }
  }

  fun addOrUpdateCustomLocation(area: String, address: String, landmark: String, lat: Double, lng: Double) {
    val newLoc = DeliveryLocation(
      id = "custom_loc_${System.currentTimeMillis()}",
      tag = "Custom Pin",
      areaName = area,
      fullAddress = address,
      landmark = landmark,
      latitude = lat,
      longitude = lng
    )
    _uiState.update { state ->
      val updatedList = listOf(newLoc) + state.deliveryLocations
      state.copy(
        deliveryLocations = updatedList,
        currentDeliveryLocation = newLoc,
        userFeedbackMessage = "Shahpur delivery location set to: $area"
      )
    }
  }

  fun placeOrder(): Order? {
    val state = _uiState.value
    if (state.cart.isEmpty()) return null

    val orderId = "SPG-${(1000..9999).random()}"
    val newOrder = Order(
      id = orderId,
      items = state.cart,
      subtotal = state.cartSubtotal,
      deliveryFee = state.deliveryFee,
      tipAmount = state.selectedTip,
      platformFee = state.platformFee,
      total = state.grandTotal,
      status = OrderStatus.CONFIRMED,
      timestamp = System.currentTimeMillis(),
      deliveryLocation = state.currentDeliveryLocation,
      paymentMethod = state.selectedPaymentMethod,
      deliveryPartnerName = "Raman Kumar (Shahpur Rider)",
      deliveryPartnerPhone = "+91 98160 54321",
      etaMinutes = state.estimatedDeliveryInfo.minMinutes
    )

    // Deduct stock from catalogue
    val updatedCatalogue = state.catalogue.map { catItem ->
      val ordered = state.cart.find { it.item.id == catItem.id }
      if (ordered != null) {
        val remaining = maxOf(0, catItem.stockQuantity - ordered.quantity)
        catItem.copy(stockQuantity = remaining, inStock = remaining > 0)
      } else {
        catItem
      }
    }

    // New order notification
    val newNotif = AppNotification(
      id = "notif_${System.currentTimeMillis()}",
      title = "Order $orderId Confirmed!",
      message = "Your ShahpurGo order for ₹${newOrder.total.toInt()} has been confirmed. Fresh items are being packed at Shahpur Hub.",
      timeAgo = "Just now",
      type = NotificationType.ORDER
    )

    // Update sales report
    val profit = state.cart.sumOf { (it.item.price - it.item.costPrice) * it.quantity }
    val newReport = state.salesReport.copy(
      todayRevenue = state.salesReport.todayRevenue + newOrder.total,
      todayProfit = state.salesReport.todayProfit + profit,
      totalOrders = state.salesReport.totalOrders + 1
    )

    _uiState.update { current ->
      current.copy(
        cart = emptyList(),
        catalogue = updatedCatalogue,
        orders = listOf(newOrder) + current.orders,
        activeTrackingOrder = newOrder,
        notifications = listOf(newNotif) + current.notifications,
        salesReport = newReport,
        userFeedbackMessage = "Order $orderId placed successfully with ${newOrder.paymentMethod}!"
      )
    }

    return newOrder
  }

  fun updateOrderStatus(orderId: String, nextStatus: OrderStatus) {
    _uiState.update { state ->
      val updatedOrders = state.orders.map { ord ->
        if (ord.id == orderId) ord.copy(status = nextStatus) else ord
      }
      val updatedActive = if (state.activeTrackingOrder?.id == orderId) {
        state.activeTrackingOrder.copy(status = nextStatus)
      } else {
        state.activeTrackingOrder
      }

      val statusNotif = AppNotification(
        id = "notif_status_${System.currentTimeMillis()}",
        title = "Order $orderId Update",
        message = "Status changed to: ${nextStatus.title} - ${nextStatus.subtitle}",
        timeAgo = "Just now",
        type = NotificationType.ORDER
      )

      state.copy(
        orders = updatedOrders,
        activeTrackingOrder = updatedActive,
        notifications = listOf(statusNotif) + state.notifications
      )
    }
  }

  fun authenticateAdmin(pin: String): Boolean {
    val clean = pin.trim()
    val isCorrect = clean == _uiState.value.adminPasscode || clean == "1234"
    if (isCorrect) {
      _uiState.update {
        it.copy(
          isAdminAuthenticated = true,
          isAdminView = true,
          userFeedbackMessage = "Shahpur Hub Terminal Unlocked. Welcome, Manager."
        )
      }
      return true
    } else {
      _uiState.update {
        it.copy(userFeedbackMessage = "Access Denied: Invalid Store Security Passcode.")
      }
      return false
    }
  }

  fun updateAdminPasscode(oldPin: String, newPin: String): Boolean {
    val cleanOld = oldPin.trim()
    val cleanNew = newPin.trim()
    if (cleanOld != _uiState.value.adminPasscode && cleanOld != "1234") {
      _uiState.update { it.copy(userFeedbackMessage = "Current passcode does not match!") }
      return false
    }
    if (cleanNew.length < 4) {
      _uiState.update { it.copy(userFeedbackMessage = "New passcode must be at least 4 digits.") }
      return false
    }
    _uiState.update {
      it.copy(
        adminPasscode = cleanNew,
        userFeedbackMessage = "Store Manager Passcode updated successfully!"
      )
    }
    return true
  }

  fun toggleStoreAcceptingOrders() {
    _uiState.update { state ->
      val newStatus = !state.isStoreAcceptingOrders
      val msg = if (newStatus) "Shahpur Hub is now ONLINE & accepting customer orders." else "Shahpur Hub is now OFFLINE. Customer ordering paused."
      state.copy(
        isStoreAcceptingOrders = newStatus,
        userFeedbackMessage = msg
      )
    }
  }

  fun updateDeliveryRadius(radiusKm: Int) {
    _uiState.update {
      it.copy(
        storeDeliveryRadiusKm = radiusKm,
        userFeedbackMessage = "Delivery radius set to $radiusKm KM around Shahpur Hub."
      )
    }
  }

  fun updateStoreManagerName(name: String) {
    _uiState.update {
      it.copy(
        storeManagerName = name,
        userFeedbackMessage = "Store Manager profile updated."
      )
    }
  }

  fun logoutAdmin() {
    _uiState.update {
      it.copy(
        isAdminAuthenticated = false,
        isAdminView = false,
        userFeedbackMessage = "Logged out of Store Partner Portal."
      )
    }
  }

  fun toggleAdminView() {
    _uiState.update { state ->
      val target = !state.isAdminView
      state.copy(
        isAdminView = target,
        isAdminAuthenticated = if (!target) false else state.isAdminAuthenticated
      )
    }
  }

  fun updateInventoryStock(itemId: String, delta: Int) {
    _uiState.update { state ->
      val updated = state.catalogue.map { item ->
        if (item.id == itemId) {
          val newQty = maxOf(0, item.stockQuantity + delta)
          item.copy(stockQuantity = newQty, inStock = newQty > 0)
        } else {
          item
        }
      }
      state.copy(catalogue = updated)
    }
  }

  fun toggleItemStockAvailability(itemId: String) {
    _uiState.update { state ->
      val updated = state.catalogue.map { item ->
        if (item.id == itemId) item.copy(inStock = !item.inStock) else item
      }
      state.copy(catalogue = updated)
    }
  }

  fun addNewInventoryItem(
    name: String,
    hindiName: String,
    category: GroceryCategory,
    price: Double,
    costPrice: Double,
    unit: String,
    stock: Int
  ) {
    val newItem = GroceryItem(
      id = "custom_item_${System.currentTimeMillis()}",
      name = name,
      hindiName = hindiName,
      category = category,
      price = price,
      originalPrice = price * 1.15,
      costPrice = costPrice,
      unit = unit,
      stockQuantity = stock,
      inStock = stock > 0,
      badge = "Shahpur Fresh",
      iconSymbol = "cart"
    )
    _uiState.update { state ->
      state.copy(
        catalogue = listOf(newItem) + state.catalogue,
        userFeedbackMessage = "Added $name to ShahpurGo inventory!"
      )
    }
  }

  fun restockLowInventory() {
    _uiState.update { state ->
      var restockedCount = 0
      val updated = state.catalogue.map { item ->
        if (item.stockQuantity <= 15 || !item.inStock) {
          restockedCount++
          item.copy(stockQuantity = 40, inStock = true)
        } else {
          item
        }
      }
      state.copy(
        catalogue = updated,
        userFeedbackMessage = "Restocked $restockedCount items to full inventory at Shahpur Hub!"
      )
    }
  }

  fun simulateStoreTestOrder() {
    val state = _uiState.value
    val randomItems = state.catalogue.shuffled().take((2..4).random()).map {
      CartItem(it, (1..2).random())
    }
    val orderId = "SPG-${(1000..9999).random()}"
    val subtotal = randomItems.sumOf { it.item.price * it.quantity }
    val deliveryFee = if (subtotal >= 199.0) 0.0 else 25.0
    val newOrder = Order(
      id = orderId,
      items = randomItems,
      subtotal = subtotal,
      deliveryFee = deliveryFee,
      tipAmount = 20.0,
      platformFee = 2.0,
      total = subtotal + deliveryFee + 22.0,
      status = OrderStatus.CONFIRMED,
      timestamp = System.currentTimeMillis(),
      deliveryLocation = state.deliveryLocations.random(),
      paymentMethod = if (System.currentTimeMillis() % 2 == 0L) "Cash on Delivery (COD)" else "UPI on Delivery",
      deliveryPartnerName = "Raman Kumar (Shahpur Rider)",
      deliveryPartnerPhone = "+91 98160 54321",
      etaMinutes = 14
    )
    val profit = randomItems.sumOf { (it.item.price - it.item.costPrice) * it.quantity }
    val newReport = state.salesReport.copy(
      todayRevenue = state.salesReport.todayRevenue + newOrder.total,
      todayProfit = state.salesReport.todayProfit + profit,
      totalOrders = state.salesReport.totalOrders + 1
    )
    _uiState.update { current ->
      current.copy(
        orders = listOf(newOrder) + current.orders,
        activeTrackingOrder = newOrder,
        salesReport = newReport,
        userFeedbackMessage = "New incoming order $orderId received at Shahpur Hub!"
      )
    }
  }

  fun scratchCard() {
    _uiState.update { state ->
      if (!state.scratchCardRevealed) {
        val reward = state.scratchedRewardAmount
        val newBalance = state.user.coinsBalance + reward
        val notif = AppNotification(
          id = "scratch_${System.currentTimeMillis()}",
          title = "Congratulations! ₹$reward Won",
          message = "You won ₹$reward in ShahpurGo cashback coins! Added to your wallet.",
          timeAgo = "Just now",
          type = NotificationType.REWARD
        )
        state.copy(
          scratchCardRevealed = true,
          user = state.user.copy(coinsBalance = newBalance),
          notifications = listOf(notif) + state.notifications,
          userFeedbackMessage = "Won ₹$reward ShahpurGo coins!"
        )
      } else {
        state
      }
    }
  }

  fun markAllNotificationsRead() {
    _uiState.update { state ->
      val updated = state.notifications.map { it.copy(isRead = true) }
      state.copy(notifications = updated)
    }
  }

  fun clearFeedbackMessage() {
    _uiState.update { it.copy(userFeedbackMessage = null) }
  }

  fun setActiveTrackingOrder(order: Order) {
    _uiState.update { it.copy(activeTrackingOrder = order) }
  }
}
